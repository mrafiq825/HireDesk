# React Component Conversion Guide: Animated Auth Card

This document provides a comprehensive guide for analyzing and converting the vanilla HTML/CSS/JavaScript animated Login/Register card into a production-ready, reusable React component.

---

## 1. Codebase Analysis & Architecture

### Existing Codebase Overview
The source project consists of 4 main files:
- [index.html](file:///Users/muhammadrafiq/Desktop/login/index.html): HTML structure defining the card container, diagonal background animation divs (`.card-bg`), logo elements (`.logo`), and two form views (`.form.signin` and `.form.signup`).
- [style.css](file:///Users/muhammadrafiq/Desktop/login/style.css): Styling and `@keyframes` animations (`card-bg-signup`, `card-bg-signin`, `card-bg-2-signup`, `card-bg-2-signin`). Uses CSS custom properties (`--color-primary: #046276`), CSS grid layout, transform rotations, and CSS general sibling combinators (`~`).
- [main.js](file:///Users/muhammadrafiq/Desktop/login/main.js): Toggles `.active`, `.signin`, and `.signup` classes on DOM elements to trigger CSS keyframe animations.
- `logo.png`: Brand image used for both login and signup headers.

### Key Technical Mechanisms to Preserve in React
1. **DOM Order for CSS Sibling Combinators (`~`)**:
   In `style.css`, rule line 158 uses the general sibling selector:
   ```css
   .card-bg.signin ~ .logo-1,
   .card-bg.signup ~ .logo-2 { ... }
   ```
   The logo `<img>` tags **must** remain directly after the `.card-bg` elements in the JSX tree to maintain logo animation behavior.
2. **Animation Triggering via Dynamic CSS Classes**:
   Keyframe animations in CSS run when specific classes (`.signin` or `.signup`) are added to `.card-bg-1` and `.card-bg-2`.
3. **Form Transition Animations**:
   Form containers animate position and opacity using `.form.active form` selectors with CSS `translate` and `transition` properties.

---

## 2. React Conversion Strategy

| Vanilla HTML/JS | React Implementation |
| :--- | :--- |
| `class="..."` | `className="..."` |
| `onclick="toggleView()"` | `onClick={() => setIsSignUp(prev => !prev)}` |
| Imperative DOM mutation (`querySelector`, `classList.toggle`) | Declarative state (`useState`) |
| Uncontrolled HTML forms | Controlled React components (`useState` for form inputs) |
| Hardcoded asset path `src="logo.png"` | ES module import `import logo from './logo.png'` |
| Native submit page reload | `e.preventDefault()` with custom `onSignIn` / `onSignUp` prop callbacks |

---

## 3. Complete Source Code

### A. React Component (`AuthCard.jsx`)

Create `src/components/AuthCard/AuthCard.jsx`:

```jsx
import React, { useState } from 'react';
import './AuthCard.css';
import logo from './logo.png'; // Ensure logo.png is placed in the component directory or public folder

export const AuthCard = ({ onSignIn, onSignUp, initialMode = 'signin' }) => {
  // State for toggling between 'signin' and 'signup'
  const [isSignUp, setIsSignUp] = useState(initialMode === 'signup');
  const [hasToggled, setHasToggled] = useState(false);

  // Controlled form state for Sign In
  const [signInData, setSignInData] = useState({
    email: '',
    password: '',
  });

  // Controlled form state for Sign Up
  const [signUpData, setSignUpData] = useState({
    name: '',
    email: '',
    password: '',
  });

  const handleToggle = (e) => {
    e.preventDefault();
    setHasToggled(true);
    setIsSignUp((prev) => !prev);
  };

  const handleSignInSubmit = (e) => {
    e.preventDefault();
    if (onSignIn) {
      onSignIn(signInData);
    }
  };

  const handleSignUpSubmit = (e) => {
    e.preventDefault();
    if (onSignUp) {
      onSignUp(signUpData);
    }
  };

  // Determine animation classes for background elements
  const bgAnimationClass = hasToggled
    ? isSignUp
      ? 'signup'
      : 'signin'
    : '';

  return (
    <div className="card">
      {/* Background animated shapes */}
      <div className={`card-bg card-bg-1 ${bgAnimationClass}`} />
      <div className={`card-bg card-bg-2 ${bgAnimationClass}`} />

      {/* Brand Logos - Order preserved for CSS sibling selectors */}
      <img className="logo logo-1" src={logo} alt="Brand Logo Login" />
      <img className="logo logo-2" src={logo} alt="Brand Logo Register" />

      {/* Sign In Form */}
      <div className={`form signin ${!isSignUp ? 'active' : ''}`}>
        <form onSubmit={handleSignInSubmit}>
          <h2>Login</h2>
          <input
            type="email"
            placeholder="Email"
            value={signInData.email}
            onChange={(e) =>
              setSignInData({ ...signInData, email: e.target.value })
            }
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={signInData.password}
            onChange={(e) =>
              setSignInData({ ...signInData, password: e.target.value })
            }
            required
          />
          <p className="forgot-password">Forgot password?</p>
          <button type="submit">SIGN IN</button>
          <a href="#signup" onClick={handleToggle}>
            Don't have an account? <em>Sign up</em>
          </a>
        </form>
      </div>

      {/* Sign Up Form */}
      <div className={`form signup ${isSignUp ? 'active' : ''}`}>
        <form onSubmit={handleSignUpSubmit}>
          <h2>Register</h2>
          <input
            type="text"
            placeholder="Name"
            value={signUpData.name}
            onChange={(e) =>
              setSignUpData({ ...signUpData, name: e.target.value })
            }
            required
          />
          <input
            type="email"
            placeholder="Email"
            value={signUpData.email}
            onChange={(e) =>
              setSignUpData({ ...signUpData, email: e.target.value })
            }
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={signUpData.password}
            onChange={(e) =>
              setSignUpData({ ...signUpData, password: e.target.value })
            }
            required
          />
          <button type="submit">SIGN UP</button>
          <a href="#signin" onClick={handleToggle}>
            Already have an account? <em>Sign in</em>
          </a>
        </form>
      </div>
    </div>
  );
};

export default AuthCard;
```

---

### B. TypeScript Component Variant (`AuthCard.tsx`)

For TypeScript React projects, create `src/components/AuthCard/AuthCard.tsx`:

```tsx
import React, { useState, FormEvent, ChangeEvent, MouseEvent } from 'react';
import './AuthCard.css';
import logo from './logo.png';

export interface SignInData {
  email: string;
  password: string;
}

export interface SignUpData {
  name: string;
  email: string;
  password: string;
}

export interface AuthCardProps {
  onSignIn?: (data: SignInData) => void;
  onSignUp?: (data: SignUpData) => void;
  initialMode?: 'signin' | 'signup';
}

export const AuthCard: React.FC<AuthCardProps> = ({
  onSignIn,
  onSignUp,
  initialMode = 'signin',
}) => {
  const [isSignUp, setIsSignUp] = useState<boolean>(initialMode === 'signup');
  const [hasToggled, setHasToggled] = useState<boolean>(false);

  const [signInData, setSignInData] = useState<SignInData>({
    email: '',
    password: '',
  });

  const [signUpData, setSignUpData] = useState<SignUpData>({
    name: '',
    email: '',
    password: '',
  });

  const handleToggle = (e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setHasToggled(true);
    setIsSignUp((prev) => !prev);
  };

  const handleSignInSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSignIn?.(signInData);
  };

  const handleSignUpSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSignUp?.(signUpData);
  };

  const bgAnimationClass = hasToggled ? (isSignUp ? 'signup' : 'signin') : '';

  return (
    <div className="card">
      <div className={`card-bg card-bg-1 ${bgAnimationClass}`} />
      <div className={`card-bg card-bg-2 ${bgAnimationClass}`} />

      <img className="logo logo-1" src={logo} alt="Brand Logo Login" />
      <img className="logo logo-2" src={logo} alt="Brand Logo Register" />

      <div className={`form signin ${!isSignUp ? 'active' : ''}`}>
        <form onSubmit={handleSignInSubmit}>
          <h2>Login</h2>
          <input
            type="email"
            placeholder="Email"
            value={signInData.email}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSignInData({ ...signInData, email: e.target.value })
            }
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={signInData.password}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSignInData({ ...signInData, password: e.target.value })
            }
            required
          />
          <p className="forgot-password">Forgot password?</p>
          <button type="submit">SIGN IN</button>
          <a href="#signup" onClick={handleToggle}>
            Don't have an account? <em>Sign up</em>
          </a>
        </form>
      </div>

      <div className={`form signup ${isSignUp ? 'active' : ''}`}>
        <form onSubmit={handleSignUpSubmit}>
          <h2>Register</h2>
          <input
            type="text"
            placeholder="Name"
            value={signUpData.name}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSignUpData({ ...signUpData, name: e.target.value })
            }
            required
          />
          <input
            type="email"
            placeholder="Email"
            value={signUpData.email}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSignUpData({ ...signUpData, email: e.target.value })
            }
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={signUpData.password}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setSignUpData({ ...signUpData, password: e.target.value })
            }
            required
          />
          <button type="submit">SIGN UP</button>
          <a href="#signin" onClick={handleToggle}>
            Already have an account? <em>Sign in</em>
          </a>
        </form>
      </div>
    </div>
  );
};

export default AuthCard;
```

---

### C. Component Styles (`AuthCard.css`)

Create `src/components/AuthCard/AuthCard.css` (adapted from original [style.css](file:///Users/muhammadrafiq/Desktop/login/style.css)):

```css
:root {
  --color-primary: #046276;
}

.card {
  position: relative;
  overflow: hidden;
  width: 660px;
  height: 440px;
  border-radius: 32px;
  background: #ffffff;
  box-shadow: 0 12px 80px rgba(0, 0, 0, 0.12);
  font-family: "Euclid Circular B", "Poppins", sans-serif;
}

.card-bg {
  position: absolute;
  z-index: 2;
  top: 0;
  bottom: 0;
  left: 0;
  width: 860px;
  height: 440px;
  rotate: -45deg;
  transform-origin: 0% 100%;
  background: var(--color-primary);
}

.card-bg-2 {
  background: var(--color-primary);
  rotate: 0deg;
  opacity: 0;
  right: 0;
  left: auto;
  transform-origin: 100% 100%;
}

/* Animations */
@keyframes card-bg-signup {
  0% {
    rotate: -45deg;
  }
  50% {
    opacity: 1;
  }
  50%,
  100% {
    rotate: 0deg;
  }
  50.01%,
  100% {
    opacity: 0;
  }
}

@keyframes card-bg-signin {
  0% {
    opacity: 0;
    rotate: 0deg;
  }
  50% {
    rotate: 0deg;
    opacity: 0;
  }
  50%,
  100% {
    rotate: 0;
  }
  50.01%,
  100% {
    opacity: 1;
  }
  100% {
    rotate: -45deg;
  }
}

@keyframes card-bg-2-signup {
  0%,
  50% {
    rotate: 0;
    opacity: 0;
  }
  50.01% {
    opacity: 1;
    rotate: 0deg;
  }
  100% {
    opacity: 1;
    rotate: 45deg;
  }
}

@keyframes card-bg-2-signin {
  0% {
    rotate: 45deg;
    opacity: 1;
  }
  50%,
  100% {
    rotate: 0deg;
    opacity: 1;
  }
  50.01%,
  100% {
    opacity: 0;
  }
}

.card-bg-1.signup {
  animation: card-bg-signup 1.5s both;
}

.card-bg-1.signin {
  animation: card-bg-signin 1.5s both;
}

.card-bg-2.signup {
  animation: card-bg-2-signup 1.5s both;
}

.card-bg-2.signin {
  animation: card-bg-2-signin 1.5s both;
}

.logo {
  position: absolute;
  top: -40px;
  z-index: 2;
  height: 300px;
  transition: 0.3s;
  opacity: 0;
}

.logo-1 {
  translate: -180px 0;
  left: 20px;
}

.logo-2 {
  translate: 180px 0;
  right: 20px;
}

/* Sibling combinators rely on DOM order */
.card-bg.signin ~ .logo-1,
.card-bg.signup ~ .logo-2 {
  opacity: 1;
  translate: 0;
  transition: 0.3s 1.25s;
}

.form {
  position: absolute;
  z-index: 3;
  top: 0;
  left: 0;
  bottom: 0;
  width: 50%;
  display: grid;
  place-items: center;
}

.form h2 {
  text-align: center;
  font-weight: 500;
  margin-bottom: 8px;
}

.form form {
  display: grid;
  gap: 12px;
  opacity: 0;
  transition: 0.3s;
}

.form a {
  display: inline-flex;
  flex-direction: column;
  gap: 8px;
  color: #a7a7ad;
  cursor: pointer;
  font-size: 14px;
  text-align: center;
  text-decoration: none;
}

.form p.forgot-password {
  font-size: 14px;
  text-align: center;
  margin: 8px 0;
  color: #a7a7ad;
  cursor: pointer;
}

.form a em {
  display: block;
  font-style: normal;
  font-size: 15px;
  color: var(--color-primary);
  font-weight: 500;
}

.form.signup {
  translate: 100% 0;
}

.form.signup form {
  translate: 320px 0;
}

.form.signin form {
  translate: -320px 0;
}

.form.signup.active form,
.form.signin.active form {
  opacity: 1;
  translate: 0;
  transition: 0.5s 1s;
}

.form input {
  width: 260px;
  padding: 0 12px;
  font-size: 14px;
  background: #f4f4f7;
  border: 0;
  border-radius: 8px;
  height: 40px;
  font-family: inherit;
  outline: none;
}

.form input::placeholder {
  color: #a7a7ad;
}

.form input:focus {
  outline: 2px solid var(--color-primary);
}

.form button {
  border: 0;
  border-radius: 8px;
  height: 40px;
  font-family: inherit;
  font-size: 14px;
  color: #f9f9f9;
  background: var(--color-primary);
  letter-spacing: 1px;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.form button:hover {
  opacity: 0.9;
}
```

---

### D. Usage Example in App (`App.jsx`)

```jsx
import React from 'react';
import AuthCard from './components/AuthCard/AuthCard';

function App() {
  const handleSignIn = (credentials) => {
    console.log('Signing in with:', credentials);
    // Add authentication API call here (e.g. axios.post('/api/login', credentials))
  };

  const handleSignUp = (userData) => {
    console.log('Registering user:', userData);
    // Add registration API call here (e.g. axios.post('/api/register', userData))
  };

  return (
    <div style={{
      display: 'grid',
      placeItems: 'center',
      minHeight: '100vh',
      backgroundColor: '#f2f3fe'
    }}>
      <AuthCard 
        onSignIn={handleSignIn} 
        onSignUp={handleSignUp} 
        initialMode="signin"
      />
    </div>
  );
}

export default App;
```

---

## 4. Verification & Testing Checklist

- [x] **DOM Hierarchy**: Ensure `.logo-1` and `.logo-2` remain sibling nodes following `.card-bg-1` and `.card-bg-2`.
- [x] **Controlled Inputs**: Verify input value bindings update correctly via `onChange` without loss of focus.
- [x] **Form Submission**: Confirm `e.preventDefault()` stops default page reloads and triggers `onSignIn`/`onSignUp` props.
- [x] **Animation Integrity**: Confirm background rotation animations fire seamlessly when switching tabs.
- [x] **Accessibility**: Added standard HTML input attributes (`type`, `placeholder`, `required`, `alt` tags on images).
